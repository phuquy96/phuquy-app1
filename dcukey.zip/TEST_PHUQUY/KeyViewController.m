#import "KeyViewController.h"
#import "MainViewController.h"
#import "PhuQuyAuth.h"

@interface KeyViewController () <UITextFieldDelegate>

@property (nonatomic, assign) BOOL isVietnamese;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIVisualEffectView *glassCard;
@property (nonatomic, strong) UIImageView *logoImageView;
@property (nonatomic, strong) UIButton *langButton;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subTitleLabel;
@property (nonatomic, strong) UILabel *hwidLabel;
@property (nonatomic, strong) UIView *inputContainer;
@property (nonatomic, strong) UITextField *keyTextField;
@property (nonatomic, strong) UIButton *pasteButton;
@property (nonatomic, strong) UIButton *verifyButton;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) UIView *errorBanner;
@property (nonatomic, strong) UILabel *errorLabel;

// Modal thành công kiểu iOS 26
@property (nonatomic, strong) UIView *successOverlay;
@property (nonatomic, strong) UIVisualEffectView *successModal;
@property (nonatomic, strong) UILabel *successTitleLabel;
@property (nonatomic, strong) UILabel *keyDisplayLabel;
@property (nonatomic, strong) UILabel *durationDisplayLabel;
@property (nonatomic, strong) UILabel *expireDisplayLabel;
@property (nonatomic, strong) UILabel *countdownLabel;
@property (nonatomic, strong) UIProgressView *countdownProgress;
@property (nonatomic, strong) NSTimer *countdownTimer;
@property (nonatomic, assign) NSInteger remainingSeconds;

@end

@implementation KeyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isVietnamese = YES;
    self.view.backgroundColor = [UIColor colorWithRed:0.04 green:0.05 blue:0.08 alpha:1.0];

    [self setupBackground];
    [self setupUI];
    [self setupSuccessModal];
    [self registerKeyboardNotifications];

    // Tự động kiểm tra Key đã lưu từ trước
    [self checkSavedKeyOnLaunch];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self updateLanguageText];
}

#pragma mark - Setup Background Glass iOS 26

- (void)setupBackground {
    // Hình nền mờ từ Logo shop
    UIImage *bgImg = [UIImage imageNamed:@"Logo"] ?: [UIImage imageNamed:@"logo.png"] ?: [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]];
    if (bgImg) {
        UIImageView *bgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
        bgView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        bgView.image = bgImg;
        bgView.contentMode = UIViewContentModeScaleAspectFill;
        bgView.alpha = 0.18;
        [self.view addSubview:bgView];
    }

    // Hiệu ứng Glass Blur nền
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
    blurView.frame = self.view.bounds;
    blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:blurView];

    // Vòng phát sáng Neon ambient mềm mại
    UIView *ambientGlow = [[UIView alloc] initWithFrame:CGRectMake(self.view.bounds.size.width/2 - 120, 100, 240, 240)];
    ambientGlow.backgroundColor = [UIColor colorWithRed:0.0 green:0.8 blue:0.6 alpha:0.12];
    ambientGlow.layer.cornerRadius = 120;
    ambientGlow.layer.masksToBounds = NO;
    ambientGlow.layer.shadowColor = [UIColor colorWithRed:0.0 green:0.9 blue:0.7 alpha:0.5].CGColor;
    ambientGlow.layer.shadowRadius = 80;
    ambientGlow.layer.shadowOpacity = 0.8;
    ambientGlow.layer.shadowOffset = CGSizeZero;
    [self.view addSubview:ambientGlow];
}

#pragma mark - Setup Main UI Card

- (void)setupUI {
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scrollView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    self.scrollView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:self.scrollView];

    UITapGestureRecognizer *dismissTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.scrollView addGestureRecognizer:dismissTap];

    self.contentView = [[UIView alloc] initWithFrame:self.view.bounds];
    self.contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.scrollView addSubview:self.contentView];

    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    CGFloat cardW = MIN(screenW - 36, 390);
    CGFloat cardH = 430;
    CGFloat cardX = (screenW - cardW) / 2;
    CGFloat cardY = MAX(60, ([UIScreen mainScreen].bounds.size.height - cardH) / 2 - 20);

    // Bảng nhập Key kiểu iOS 26 Glass Kính
    UIBlurEffect *cardBlur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    self.glassCard = [[UIVisualEffectView alloc] initWithEffect:cardBlur];
    self.glassCard.frame = CGRectMake(cardX, cardY, cardW, cardH);
    self.glassCard.layer.cornerRadius = 28;
    self.glassCard.layer.masksToBounds = YES;
    self.glassCard.layer.borderWidth = 1.5;
    self.glassCard.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.25].CGColor;
    self.glassCard.layer.backgroundColor = [UIColor colorWithRed:0.08 green:0.11 blue:0.16 alpha:0.75].CGColor;
    [self.contentView addSubview:self.glassCard];

    UIView *cardInner = self.glassCard.contentView;

    // 1. Logo trên cùng giữa bảng nhập key
    UIImage *logoImg = [UIImage imageNamed:@"Logo"] ?: [UIImage imageNamed:@"logo.png"] ?: [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]];
    self.logoImageView = [[UIImageView alloc] initWithFrame:CGRectMake((cardW - 80) / 2, 22, 80, 64)];
    self.logoImageView.image = logoImg;
    self.logoImageView.contentMode = UIViewContentModeScaleAspectFit;
    self.logoImageView.layer.cornerRadius = 14;
    self.logoImageView.layer.masksToBounds = YES;
    self.logoImageView.layer.borderWidth = 1.0;
    self.logoImageView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.35].CGColor;
    [cardInner addSubview:self.logoImageView];

    // 2. Nút nhỏ chọn ngôn ngữ ở góc trên cùng bên phải bảng nhập key
    self.langButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.langButton.frame = CGRectMake(cardW - 120, 16, 105, 34);
    self.langButton.layer.cornerRadius = 17;
    self.langButton.layer.borderWidth = 1.0;
    self.langButton.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.3].CGColor;
    self.langButton.backgroundColor = [UIColor colorWithWhite:0.12 alpha:0.8];
    self.langButton.titleLabel.font = [UIFont boldSystemFontOfSize:11.5];
    [self.langButton setTitle:@"🇻🇳 VIETNAM" forState:UIControlStateNormal];
    [self.langButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.langButton addTarget:self action:@selector(showLanguageActionSheet) forControlEvents:UIControlEventTouchUpInside];
    [cardInner addSubview:self.langButton];

    // 3. Tiêu đề và hướng dẫn
    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 96, cardW - 32, 26)];
    self.titleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightHeavy];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.textColor = [UIColor whiteColor];
    [cardInner addSubview:self.titleLabel];

    self.subTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 124, cardW - 32, 20)];
    self.subTitleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightMedium];
    self.subTitleLabel.textAlignment = NSTextAlignmentCenter;
    self.subTitleLabel.textColor = [UIColor colorWithWhite:0.75 alpha:1.0];
    [cardInner addSubview:self.subTitleLabel];

    // HWID hiển thị nhỏ
    NSString *hwid = [PhuQuyAuth getDeviceHWID];
    NSString *shortHwid = hwid.length > 16 ? [NSString stringWithFormat:@"%@...%@", [hwid substringToIndex:8], [hwid substringFromIndex:hwid.length-6]] : hwid;
    self.hwidLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 146, cardW - 32, 18)];
    self.hwidLabel.font = [UIFont fontWithName:@"Menlo" size:10.5] ?: [UIFont monospacedSystemFontOfSize:10.5 weight:UIFontWeightRegular];
    self.hwidLabel.textAlignment = NSTextAlignmentCenter;
    self.hwidLabel.textColor = [UIColor colorWithRed:0.4 green:0.85 blue:0.95 alpha:0.9];
    self.hwidLabel.text = [NSString stringWithFormat:@"HWID: %@", shortHwid];
    [cardInner addSubview:self.hwidLabel];

    // 4. Khung Ô nhập key + Nút Dán sát bên
    CGFloat inputY = 176;
    CGFloat inputH = 52;
    self.inputContainer = [[UIView alloc] initWithFrame:CGRectMake(18, inputY, cardW - 36, inputH)];
    self.inputContainer.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.85];
    self.inputContainer.layer.cornerRadius = 16;
    self.inputContainer.layer.borderWidth = 1.2;
    self.inputContainer.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.25].CGColor;
    [cardInner addSubview:self.inputContainer];

    CGFloat pasteBtnW = 78;
    CGFloat tfW = (cardW - 36) - pasteBtnW - 14;

    self.keyTextField = [[UITextField alloc] initWithFrame:CGRectMake(14, 0, tfW, inputH)];
    self.keyTextField.textColor = [UIColor whiteColor];
    self.keyTextField.font = [UIFont boldSystemFontOfSize:15];
    self.keyTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.keyTextField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.keyTextField.returnKeyType = UIReturnKeyDone;
    self.keyTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.keyTextField.delegate = self;
    [self.inputContainer addSubview:self.keyTextField];

    // Nút Dán sao ô nhập key
    self.pasteButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.pasteButton.frame = CGRectMake((cardW - 36) - pasteBtnW - 6, 8, pasteBtnW, inputH - 16);
    self.pasteButton.backgroundColor = [UIColor colorWithRed:0.15 green:0.22 blue:0.35 alpha:0.9];
    self.pasteButton.layer.cornerRadius = 12;
    self.pasteButton.layer.borderWidth = 1.0;
    self.pasteButton.layer.borderColor = [UIColor colorWithRed:0.3 green:0.6 blue:1.0 alpha:0.5].CGColor;
    self.pasteButton.titleLabel.font = [UIFont boldSystemFontOfSize:12.5];
    [self.pasteButton setTitleColor:[UIColor colorWithRed:0.4 green:0.8 blue:1.0 alpha:1.0] forState:UIControlStateNormal];
    [self.pasteButton addTarget:self action:@selector(pasteKeyAction) forControlEvents:UIControlEventTouchUpInside];
    [self.inputContainer addSubview:self.pasteButton];

    // 5. Nút Xác Thực Key (Hiệu ứng iOS 26 Glass Gradient)
    CGFloat btnY = inputY + inputH + 20;
    self.verifyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.verifyButton.frame = CGRectMake(18, btnY, cardW - 36, 52);
    self.verifyButton.layer.cornerRadius = 16;
    self.verifyButton.layer.masksToBounds = YES;
    self.verifyButton.layer.borderWidth = 1.5;
    self.verifyButton.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.4].CGColor;
    self.verifyButton.backgroundColor = [UIColor colorWithRed:0.0 green:0.65 blue:0.55 alpha:0.95];
    self.verifyButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightHeavy];
    [self.verifyButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.verifyButton addTarget:self action:@selector(verifyKeyAction) forControlEvents:UIControlEventTouchUpInside];
    [cardInner addSubview:self.verifyButton];

    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    self.spinner.color = [UIColor whiteColor];
    self.spinner.center = CGPointMake((cardW - 36) / 2 + 90, 26);
    self.spinner.hidesWhenStopped = YES;
    [self.verifyButton addSubview:self.spinner];

    // 6. Banner Thông báo lỗi (Key Không Tồn Tại, Key Đã Hết Hạn, Key Đã Bị Band, v.v...)
    self.errorBanner = [[UIView alloc] initWithFrame:CGRectMake(18, btnY + 60, cardW - 36, 48)];
    self.errorBanner.backgroundColor = [UIColor colorWithRed:0.65 green:0.1 blue:0.15 alpha:0.85];
    self.errorBanner.layer.cornerRadius = 14;
    self.errorBanner.layer.borderWidth = 1.0;
    self.errorBanner.layer.borderColor = [UIColor colorWithRed:1.0 green:0.3 blue:0.35 alpha:0.6].CGColor;
    self.errorBanner.hidden = YES;
    [cardInner addSubview:self.errorBanner];

    self.errorLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 4, self.errorBanner.frame.size.width - 20, 40)];
    self.errorLabel.textColor = [UIColor whiteColor];
    self.errorLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightBold];
    self.errorLabel.textAlignment = NSTextAlignmentCenter;
    self.errorLabel.numberOfLines = 2;
    [self.errorBanner addSubview:self.errorLabel];
}

#pragma mark - Setup Success Modal (Ô vuông bo góc glass iOS 26)

- (void)setupSuccessModal {
    // Lớp phủ làm mờ toàn màn hình
    self.successOverlay = [[UIView alloc] initWithFrame:self.view.bounds];
    self.successOverlay.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.successOverlay.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.75];
    self.successOverlay.alpha = 0.0;
    self.successOverlay.hidden = YES;
    [self.view addSubview:self.successOverlay];

    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    CGFloat modalSize = MIN(screenW - 44, 320);
    CGFloat modalX = (screenW - modalSize) / 2;
    CGFloat modalY = ([UIScreen mainScreen].bounds.size.height - modalSize) / 2;

    // Bảng ô vuông bo tròn góc nền đen viền trắng glass ios 26
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    self.successModal = [[UIVisualEffectView alloc] initWithEffect:blur];
    self.successModal.frame = CGRectMake(modalX, modalY, modalSize, modalSize);
    self.successModal.layer.cornerRadius = 28;
    self.successModal.layer.masksToBounds = YES;
    self.successModal.layer.borderWidth = 1.8;
    self.successModal.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.5].CGColor;
    self.successModal.layer.backgroundColor = [UIColor colorWithRed:0.07 green:0.09 blue:0.13 alpha:0.92].CGColor;
    [self.successOverlay addSubview:self.successModal];

    UIView *modalInner = self.successModal.contentView;

    // Nút tích nằm trong ô tròn phía trên cùng giữa ô vuông
    CGFloat iconSize = 52;
    UIView *checkCircle = [[UIView alloc] initWithFrame:CGRectMake((modalSize - iconSize) / 2, 18, iconSize, iconSize)];
    checkCircle.backgroundColor = [UIColor colorWithRed:0.0 green:0.8 blue:0.45 alpha:0.25];
    checkCircle.layer.cornerRadius = iconSize / 2;
    checkCircle.layer.borderWidth = 2.0;
    checkCircle.layer.borderColor = [UIColor colorWithRed:0.1 green:0.95 blue:0.55 alpha:0.9].CGColor;
    [modalInner addSubview:checkCircle];

    UILabel *checkIcon = [[UILabel alloc] initWithFrame:checkCircle.bounds];
    checkIcon.text = @"✓";
    checkIcon.font = [UIFont systemFontOfSize:28 weight:UIFontWeightHeavy];
    checkIcon.textColor = [UIColor colorWithRed:0.2 green:1.0 blue:0.6 alpha:1.0];
    checkIcon.textAlignment = NSTextAlignmentCenter;
    [checkCircle addSubview:checkIcon];

    // Tiêu đề
    self.successTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 76, modalSize - 24, 22)];
    self.successTitleLabel.font = [UIFont systemFontOfSize:15.5 weight:UIFontWeightHeavy];
    self.successTitleLabel.textColor = [UIColor whiteColor];
    self.successTitleLabel.textAlignment = NSTextAlignmentCenter;
    [modalInner addSubview:self.successTitleLabel];

    // Card chứa thông tin 3 dòng: KEY, THỜI HẠN, HẾT HẠN
    UIView *infoBox = [[UIView alloc] initWithFrame:CGRectMake(16, 106, modalSize - 32, 126)];
    infoBox.backgroundColor = [UIColor colorWithWhite:0.04 alpha:0.8];
    infoBox.layer.cornerRadius = 16;
    infoBox.layer.borderWidth = 1.0;
    infoBox.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
    [modalInner addSubview:infoBox];

    CGFloat rowH = 40;
    // Dòng 1: KEY
    self.keyDisplayLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 2, infoBox.frame.size.width - 24, rowH)];
    self.keyDisplayLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    self.keyDisplayLabel.textColor = [UIColor colorWithWhite:0.95 alpha:1.0];
    [infoBox addSubview:self.keyDisplayLabel];

    UIView *div1 = [[UIView alloc] initWithFrame:CGRectMake(12, 41, infoBox.frame.size.width - 24, 0.6)];
    div1.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.12];
    [infoBox addSubview:div1];

    // Dòng 2: THỜI HẠN
    self.durationDisplayLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 43, infoBox.frame.size.width - 24, rowH)];
    self.durationDisplayLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    self.durationDisplayLabel.textColor = [UIColor colorWithRed:0.35 green:0.85 blue:1.0 alpha:1.0];
    [infoBox addSubview:self.durationDisplayLabel];

    UIView *div2 = [[UIView alloc] initWithFrame:CGRectMake(12, 83, infoBox.frame.size.width - 24, 0.6)];
    div2.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.12];
    [infoBox addSubview:div2];

    // Dòng 3: HẾT HẠN
    self.expireDisplayLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 85, infoBox.frame.size.width - 24, rowH)];
    self.expireDisplayLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightBold];
    self.expireDisplayLabel.textColor = [UIColor colorWithRed:1.0 green:0.85 blue:0.35 alpha:1.0];
    [infoBox addSubview:self.expireDisplayLabel];

    // Đếm ngược 5 giây vào trong
    self.countdownLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 240, modalSize - 32, 20)];
    self.countdownLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightMedium];
    self.countdownLabel.textColor = [UIColor colorWithWhite:0.75 alpha:1.0];
    self.countdownLabel.textAlignment = NSTextAlignmentCenter;
    [modalInner addSubview:self.countdownLabel];

    self.countdownProgress = [[UIProgressView alloc] initWithFrame:CGRectMake(36, 268, modalSize - 72, 4)];
    self.countdownProgress.progressTintColor = [UIColor colorWithRed:0.0 green:0.85 blue:0.55 alpha:1.0];
    self.countdownProgress.trackTintColor = [UIColor colorWithWhite:0.2 alpha:0.5];
    self.countdownProgress.progress = 1.0;
    [modalInner addSubview:self.countdownProgress];

    // Nút Vào Ngay (không cần chờ 5s)
    UIButton *enterNowBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    enterNowBtn.frame = CGRectMake(24, 280, modalSize - 48, 28);
    enterNowBtn.titleLabel.font = [UIFont boldSystemFontOfSize:12];
    [enterNowBtn setTitle:self.isVietnamese ? @"⚡ Vào Ngay" : @"⚡ Enter Now" forState:UIControlStateNormal];
    [enterNowBtn setTitleColor:[UIColor colorWithRed:0.4 green:0.85 blue:1.0 alpha:1.0] forState:UIControlStateNormal];
    [enterNowBtn addTarget:self action:@selector(proceedToMainScreen) forControlEvents:UIControlEventTouchUpInside];
    [modalInner addSubview:enterNowBtn];
}

#pragma mark - Actions

- (void)showLanguageActionSheet {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:self.isVietnamese ? @"Chọn Ngôn Ngữ" : @"Select Language"
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    UIAlertAction *vnAction = [UIAlertAction actionWithTitle:@"🇻🇳 VIETNAM"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * _Nonnull action) {
        self.isVietnamese = YES;
        [self updateLanguageText];
    }];

    UIAlertAction *enAction = [UIAlertAction actionWithTitle:@"🇬🇧 ENGLISH"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * _Nonnull action) {
        self.isVietnamese = NO;
        [self updateLanguageText];
    }];

    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:self.isVietnamese ? @"Hủy" : @"Cancel"
                                                           style:UIAlertActionStyleCancel
                                                         handler:nil];

    [alert addAction:vnAction];
    [alert addAction:enAction];
    [alert addAction:cancelAction];

    // Hỗ trợ iPad popover
    if (alert.popoverPresentationController) {
        alert.popoverPresentationController.sourceView = self.langButton;
        alert.popoverPresentationController.sourceRect = self.langButton.bounds;
    }

    [self presentViewController:alert animated:YES completion:nil];
}

- (void)updateLanguageText {
    if (self.isVietnamese) {
        [self.langButton setTitle:@"🇻🇳 VIETNAM" forState:UIControlStateNormal];
        self.titleLabel.text = @"HỆ THỐNG XÁC THỰC PHUQUY";
        self.subTitleLabel.text = @"Vui lòng nhập Key bản quyền để kích hoạt";
        self.keyTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Nhập mã Key tại đây..."
                                                                                  attributes:@{NSForegroundColorAttributeName: [UIColor colorWithWhite:0.5 alpha:1.0]}];
        [self.pasteButton setTitle:@"📋 Dán" forState:UIControlStateNormal];
        [self.verifyButton setTitle:@"⚡ XÁC THỰC KEY" forState:UIControlStateNormal];
        self.successTitleLabel.text = @"XÁC THỰC THÀNH CÔNG";
    } else {
        [self.langButton setTitle:@"🇬🇧 ENGLISH" forState:UIControlStateNormal];
        self.titleLabel.text = @"PHUQUY AUTH SYSTEM";
        self.subTitleLabel.text = @"Enter your license key to activate";
        self.keyTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Enter license key here..."
                                                                                  attributes:@{NSForegroundColorAttributeName: [UIColor colorWithWhite:0.5 alpha:1.0]}];
        [self.pasteButton setTitle:@"📋 Paste" forState:UIControlStateNormal];
        [self.verifyButton setTitle:@"⚡ VERIFY KEY" forState:UIControlStateNormal];
        self.successTitleLabel.text = @"VERIFIED SUCCESSFULLY";
    }
}

- (void)pasteKeyAction {
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    NSString *copiedText = pasteboard.string;
    if (copiedText && copiedText.length > 0) {
        self.keyTextField.text = [copiedText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [self hideError];
        
        // Hiệu ứng haptic rung nhẹ
        if (@available(iOS 10.0, *)) {
            UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
            [gen impactOccurred];
        }
    } else {
        [self showError:self.isVietnamese ? @"Không có dữ liệu trong bộ nhớ tạm!" : @"Clipboard is empty!"];
    }
}

- (void)verifyKeyAction {
    [self dismissKeyboard];
    NSString *inputKey = self.keyTextField.text;

    if (!inputKey || inputKey.length == 0) {
        [self showError:self.isVietnamese ? @"Vui lòng nhập Key trước khi xác thực!" : @"Please enter your Key first!"];
        return;
    }

    [self hideError];
    [self.spinner startAnimating];
    self.verifyButton.enabled = NO;
    self.verifyButton.alpha = 0.75;

    [PhuQuyAuth verifyKeyDetailed:inputKey success:^(NSDictionary * _Nonnull keyData) {
        [self.spinner stopAnimating];
        self.verifyButton.enabled = YES;
        self.verifyButton.alpha = 1.0;

        NSString *key = keyData[@"key"] ?: inputKey;
        NSString *duration = keyData[@"duration"] ?: @"1 Ngày";
        NSString *expireTime = keyData[@"expire_time"] ?: @"";

        [self showSuccessModalWithKey:key duration:duration expireTime:expireTime];
    } failure:^(NSString * _Nonnull errorMessage, NSString * _Nonnull errorCode) {
        [self.spinner stopAnimating];
        self.verifyButton.enabled = YES;
        self.verifyButton.alpha = 1.0;

        // Xử lý thông báo theo ngôn ngữ
        NSString *translatedMsg = errorMessage;
        if (!self.isVietnamese) {
            if ([errorCode isEqualToString:@"KEY_NOT_FOUND"]) translatedMsg = @"Key Does Not Exist";
            else if ([errorCode isEqualToString:@"KEY_EXPIRED"]) translatedMsg = @"Key Has Expired";
            else if ([errorCode isEqualToString:@"KEY_BANNED"]) translatedMsg = @"Key Has Been Banned";
            else if ([errorCode isEqualToString:@"KEY_DELETED"]) translatedMsg = @"Key Has Been Deleted";
            else if ([errorCode isEqualToString:@"HWID_MISMATCH"]) translatedMsg = @"Key Active On Another Device";
        }

        [self showError:translatedMsg];

        if (@available(iOS 10.0, *)) {
            UINotificationFeedbackGenerator *gen = [[UINotificationFeedbackGenerator alloc] init];
            [gen notificationOccurred:UINotificationFeedbackTypeError];
        }
    }];
}

- (void)showSuccessModalWithKey:(NSString *)key duration:(NSString *)duration expireTime:(NSString *)expireTime {
    if (self.isVietnamese) {
        self.keyDisplayLabel.text = [NSString stringWithFormat:@"KEY : %@", key];
        self.durationDisplayLabel.text = [NSString stringWithFormat:@"THỜI HẠN : %@", duration];
        self.expireDisplayLabel.text = [NSString stringWithFormat:@"HẾT HẠN : %@", expireTime];
    } else {
        self.keyDisplayLabel.text = [NSString stringWithFormat:@"KEY : %@", key];
        self.durationDisplayLabel.text = [NSString stringWithFormat:@"DURATION : %@", duration];
        self.expireDisplayLabel.text = [NSString stringWithFormat:@"EXPIRES AT : %@", expireTime];
    }

    self.remainingSeconds = 5;
    [self updateCountdownText];
    self.countdownProgress.progress = 1.0;

    self.successOverlay.hidden = NO;
    self.successModal.transform = CGAffineTransformMakeScale(0.8, 0.8);
    [UIView animateWithDuration:0.35 delay:0.0 usingSpringWithDamping:0.8 initialSpringVelocity:0.5 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.successOverlay.alpha = 1.0;
        self.successModal.transform = CGAffineTransformIdentity;
    } completion:nil];

    if (@available(iOS 10.0, *)) {
        UINotificationFeedbackGenerator *gen = [[UINotificationFeedbackGenerator alloc] init];
        [gen notificationOccurred:UINotificationFeedbackTypeSuccess];
    }

    // Bắt đầu đếm ngược 5 giây
    [self.countdownTimer invalidate];
    self.countdownTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES block:^(NSTimer * _Nonnull timer) {
        self.remainingSeconds--;
        self.countdownProgress.progress = (float)self.remainingSeconds / 5.0;
        [self updateCountdownText];

        if (self.remainingSeconds <= 0) {
            [timer invalidate];
            [self proceedToMainScreen];
        }
    }];
}

- (void)updateCountdownText {
    if (self.isVietnamese) {
        self.countdownLabel.text = [NSString stringWithFormat:@"Tự động vào giao diện sau %lds...", (long)self.remainingSeconds];
    } else {
        self.countdownLabel.text = [NSString stringWithFormat:@"Entering dashboard in %lds...", (long)self.remainingSeconds];
    }
}

- (void)proceedToMainScreen {
    [self.countdownTimer invalidate];
    self.countdownTimer = nil;

    [UIView animateWithDuration:0.25 animations:^{
        self.successOverlay.alpha = 0.0;
        self.successModal.transform = CGAffineTransformMakeScale(0.9, 0.9);
    } completion:^(BOOL finished) {
        self.successOverlay.hidden = YES;

        MainViewController *mainVC = [[MainViewController alloc] init];
        mainVC.isVietnamese = self.isVietnamese;
        mainVC.modalPresentationStyle = UIModalPresentationFullScreen;
        mainVC.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:mainVC animated:YES completion:nil];
    }];
}

#pragma mark - Saved Key Check

- (void)checkSavedKeyOnLaunch {
    NSString *savedKey = [PhuQuyAuth getSavedKey];
    if (savedKey && savedKey.length > 0) {
        self.keyTextField.text = savedKey;
        // Tự động kiểm tra tính hợp lệ trong nền
        [PhuQuyAuth verifyKeyDetailed:savedKey success:^(NSDictionary * _Nonnull keyData) {
            // Key còn hợp lệ -> Vào thẳng giao diện chính không cần nhập lại
            MainViewController *mainVC = [[MainViewController alloc] init];
            mainVC.isVietnamese = self.isVietnamese;
            mainVC.modalPresentationStyle = UIModalPresentationFullScreen;
            [self presentViewController:mainVC animated:NO completion:nil];
        } failure:^(NSString * _Nonnull errorMessage, NSString * _Nonnull errorCode) {
            // Key hết hạn hoặc bị hủy -> Xóa và yêu cầu nhập lại
            [PhuQuyAuth clearSavedKey];
            [self showError:errorMessage];
        }];
    }
}

#pragma mark - Errors

- (void)showKickReason:(NSString *)reason {
    [self showError:reason];
}

- (void)showError:(NSString *)msg {
    self.errorLabel.text = msg;
    self.errorBanner.hidden = NO;
    self.errorBanner.alpha = 0.0;
    self.errorBanner.transform = CGAffineTransformMakeTranslation(0, -10);

    [UIView animateWithDuration:0.25 animations:^{
        self.errorBanner.alpha = 1.0;
        self.errorBanner.transform = CGAffineTransformIdentity;
    }];
}

- (void)hideError {
    if (!self.errorBanner.hidden) {
        [UIView animateWithDuration:0.2 animations:^{
            self.errorBanner.alpha = 0.0;
        } completion:^(BOOL finished) {
            self.errorBanner.hidden = YES;
        }];
    }
}

#pragma mark - Keyboard

- (void)dismissKeyboard {
    [self.view endEditing:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    [self verifyKeyAction];
    return YES;
}

- (void)registerKeyboardNotifications {
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

- (void)keyboardWillShow:(NSNotification *)note {
    NSDictionary *info = note.userInfo;
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    [UIView animateWithDuration:0.3 animations:^{
        self.scrollView.contentInset = UIEdgeInsetsMake(0, 0, kbSize.height + 20, 0);
    }];
}

- (void)keyboardWillHide:(NSNotification *)note {
    [UIView animateWithDuration:0.3 animations:^{
        self.scrollView.contentInset = UIEdgeInsetsZero;
    }];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

@end
