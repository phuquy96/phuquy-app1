// =========================================================================
// [PHUQUY SEVER] CODE GẮN SẴN VÀO MENU IOS (TWEAK.X / THEOS / DYLIB / APP)
// TỰ ĐỘNG LẤY HWID MÁY • TRẢ KẾT QUẢ TỨC THÌ • TỰ ĐỘNG KICK NGAY KHI RESET/XÓA/KHÓA/HẾT HẠN
// =========================================================================

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^PQSuccessBlock)(NSDictionary *keyData);
typedef void (^PQFailureBlock)(NSString *errorMessage, NSString *errorCode);
typedef void (^PQRevokeBlock)(NSString *reason);

@interface PhuQuyAuth : NSObject

@property (nonatomic, copy, class) NSString *appToken;
@property (nonatomic, copy, class) NSString *apiUrl;
@property (nonatomic, copy, class, nullable) NSString *currentKey;
@property (nonatomic, copy, class, nullable) NSString *currentDuration;
@property (nonatomic, copy, class, nullable) NSString *currentExpireTime;
@property (nonatomic, assign, class) BOOL isAuthorized;

/// Khởi tạo cấu hình kết nối Máy Chủ PHUQUY
+ (void)configureWithToken:(NSString *)token apiUrl:(NSString *)apiUrl;

/// Tự động lấy HWID máy duy nhất
+ (NSString *)getDeviceHWID;

/// Xác thực bản quyền từ máy chủ PHUQUY
+ (void)startAuthorization:(NSString *)userKey
                   onValid:(void(^)(void))onValid
                 onRevoked:(void(^)(void))onRevoked;

/// Xác thực chi tiết trả về thông tin Key, Thời hạn, Ngày hết hạn
+ (void)verifyKeyDetailed:(NSString *)userKey
                  success:(PQSuccessBlock)success
                  failure:(PQFailureBlock)failure;

/// Bắt đầu cơ chế kiểm tra Realtime Heartbeat (mặc định mỗi 10 giây)
+ (void)startRealtimeHeartbeatWithInterval:(NSTimeInterval)interval
                                 onRevoked:(PQRevokeBlock)onRevoked;

/// Dừng kiểm tra Realtime Heartbeat
+ (void)stopRealtimeHeartbeat;

/// Lưu / Đọc Key từ bộ nhớ máy
+ (void)saveKeyLocally:(NSString *)key duration:(NSString *)duration expireTime:(NSString *)expireTime;
+ (nullable NSString *)getSavedKey;
+ (nullable NSString *)getSavedDuration;
+ (nullable NSString *)getSavedExpireTime;
+ (void)clearSavedKey;

@end

// =========================================================================
// HÀM TOÀN CỤC CHUẨN C / OBJECTIVE-C THEO ĐÚNG MẪU SEVER PHUQUY
// =========================================================================
void PhuQuyConfigure(NSString *appToken, NSString *apiUrl);
void PhuQuyStartAuthorization(NSString *userKey, void(^onValid)(void), void(^onRevoked)(void));
void SetupModMenu(void);
void TeardownModMenu(void);

NS_ASSUME_NONNULL_END
