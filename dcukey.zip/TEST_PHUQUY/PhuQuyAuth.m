#import "PhuQuyAuth.h"

static NSString *g_appToken = @"PQ-LIVE-1-F115E83639653E38";
static NSString *g_apiUrl = @"https://severphuquy.sbs/api/server_key.php";
static NSString *g_currentKey = nil;
static NSString *g_currentDuration = nil;
static NSString *g_currentExpireTime = nil;
static BOOL g_isAuthorized = NO;
static NSTimer *g_heartbeatTimer = nil;
static void (^g_onRevokedHandler)(void) = nil;

@implementation PhuQuyAuth

+ (NSString *)appToken {
    return g_appToken;
}
+ (void)setAppToken:(NSString *)token {
    g_appToken = [token copy];
}

+ (NSString *)apiUrl {
    return g_apiUrl;
}
+ (void)setApiUrl:(NSString *)url {
    g_apiUrl = [url copy];
}

+ (NSString *)currentKey {
    return g_currentKey;
}
+ (void)setCurrentKey:(NSString *)key {
    g_currentKey = [key copy];
}

+ (NSString *)currentDuration {
    return g_currentDuration;
}
+ (void)setCurrentDuration:(NSString *)duration {
    g_currentDuration = [duration copy];
}

+ (NSString *)currentExpireTime {
    return g_currentExpireTime;
}
+ (void)setCurrentExpireTime:(NSString *)expireTime {
    g_currentExpireTime = [expireTime copy];
}

+ (BOOL)isAuthorized {
    return g_isAuthorized;
}
+ (void)setIsAuthorized:(BOOL)authorized {
    g_isAuthorized = authorized;
}

+ (instancetype)sharedInstance {
    static PhuQuyAuth *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[PhuQuyAuth alloc] init];
    });
    return instance;
}

+ (void)configureWithToken:(NSString *)token apiUrl:(NSString *)apiUrl {
    self.appToken = token;
    self.apiUrl = apiUrl;
    NSLog(@"[PHUQUY SEVER] Đã kết nối máy chủ: %@", apiUrl);
}

+ (NSString *)getDeviceHWID {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *savedHWID = [defaults stringForKey:@"PQ_DEVICE_HWID"];
    if (savedHWID && savedHWID.length > 0) {
        return savedHWID;
    }
    
    NSString *vendorId = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    if (!vendorId || vendorId.length == 0) {
        vendorId = [[NSUUID UUID] UUIDString];
    }
    
    [defaults setObject:vendorId forKey:@"PQ_DEVICE_HWID"];
    [defaults synchronize];
    return vendorId;
}

+ (void)verifyKeyDetailed:(NSString *)userKey
                  success:(PQSuccessBlock)success
                  failure:(PQFailureBlock)failure {
    if (!userKey || userKey.length == 0) {
        if (failure) failure(@"Vui lòng nhập mã Key!", @"EMPTY_KEY");
        return;
    }

    NSString *trimmedKey = [userKey stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *hwid = [self getDeviceHWID];
    NSString *token = self.appToken ?: @"PQ-LIVE-1-F115E83639653E38";
    NSString *endpoint = self.apiUrl ?: @"https://severphuquy.sbs/api/server_key.php";

    // 1. CHẾ ĐỘ TEST KEY NỘI BỘ (Khi chưa tạo key trên sever admin panel)
    NSString *upperKey = [trimmedKey uppercaseString];
    if ([upperKey isEqualToString:@"TEST-PHUQUY-VIP"] ||
        [upperKey isEqualToString:@"PQ-VIP-2026-OK"] ||
        [upperKey isEqualToString:@"PHUQUY2026"] ||
        [upperKey isEqualToString:@"ADMIN"]) {
        
        NSDate *now = [NSDate date];
        NSDate *expireDate = [now dateByAddingTimeInterval:86400]; // 1 Ngày
        NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
        [fmt setDateFormat:@"dd/MM/yyyy HH:mm:ss"];
        NSString *expStr = [fmt stringFromDate:expireDate];

        self.currentKey = trimmedKey;
        self.currentDuration = @"1 Ngày";
        self.currentExpireTime = expStr;
        self.isAuthorized = YES;
        [self saveKeyLocally:trimmedKey duration:@"1 Ngày" expireTime:expStr];

        if (success) {
            success(@{
                @"key": trimmedKey,
                @"duration": @"1 Ngày",
                @"expire_time": expStr,
                @"status": @"success"
            });
        }
        return;
    }

    // 2. GỬI YÊU CẦU LÊN SEVER PHUQUY (Gửi cả GET URL và POST Body để tương thích 100%)
    NSString *urlWithQuery = [NSString stringWithFormat:@"%@?key=%@&token=%@&hwid=%@&action=verify",
                              endpoint,
                              [self urlEncode:trimmedKey],
                              [self urlEncode:token],
                              [self urlEncode:hwid]];

    NSURL *url = [NSURL URLWithString:urlWithQuery];
    if (!url) {
        if (failure) failure(@"Địa chỉ máy chủ không hợp lệ!", @"INVALID_URL");
        return;
    }

    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setTimeoutInterval:15.0];
    [request setValue:@"application/x-www-form-urlencoded; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) PhuQuyClient/2.0" forHTTPHeaderField:@"User-Agent"];

    NSString *postBody = [NSString stringWithFormat:@"token=%@&key=%@&hwid=%@&action=verify",
                          [self urlEncode:token],
                          [self urlEncode:trimmedKey],
                          [self urlEncode:hwid]];
    [request setHTTPBody:[postBody dataUsingEncoding:NSUTF8StringEncoding]];

    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    config.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config];

    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                if (failure) {
                    failure([NSString stringWithFormat:@"Lỗi kết nối máy chủ: %@", error.localizedDescription], @"NETWORK_ERROR");
                }
                return;
            }

            NSHTTPURLResponse *httpResp = (NSHTTPURLResponse *)response;
            if (!data || data.length == 0) {
                if (failure) failure(@"Máy chủ không phản hồi dữ liệu!", @"EMPTY_RESPONSE");
                return;
            }

            NSError *jsonErr = nil;
            id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&jsonErr];
            NSString *rawString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ?: @"";

            if ([jsonObject isKindOfClass:[NSDictionary class]]) {
                NSDictionary *resDict = (NSDictionary *)jsonObject;
                NSString *status = [[resDict objectForKey:@"status"] description].lowercaseString;
                NSString *message = [resDict objectForKey:@"message"] ?: [resDict objectForKey:@"msg"] ?: @"";
                NSString *detail = [resDict objectForKey:@"detail"] ?: @"";
                BOOL isValid = NO;

                if ([resDict objectForKey:@"valid"]) {
                    isValid = [[resDict objectForKey:@"valid"] boolValue];
                }
                if ([status isEqualToString:@"success"] || [status isEqualToString:@"valid"] || [status isEqualToString:@"1"] || [status isEqualToString:@"ok"]) {
                    isValid = YES;
                }

                // KEY HỢP LỆ
                if (isValid) {
                    NSString *duration = [resDict objectForKey:@"duration"] ?: [resDict objectForKey:@"time"] ?: @"1 Ngày";
                    NSString *expireTime = [resDict objectForKey:@"expire_time"] ?: [resDict objectForKey:@"expiration"] ?: [resDict objectForKey:@"expired_at"] ?: @"";

                    if (expireTime.length == 0) {
                        NSDate *expDate = [[NSDate date] dateByAddingTimeInterval:86400];
                        NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
                        [fmt setDateFormat:@"dd/MM/yyyy HH:mm:ss"];
                        expireTime = [fmt stringFromDate:expDate];
                    }

                    self.currentKey = trimmedKey;
                    self.currentDuration = duration;
                    self.currentExpireTime = expireTime;
                    self.isAuthorized = YES;
                    [self saveKeyLocally:trimmedKey duration:duration expireTime:expireTime];

                    if (success) {
                        success(@{
                            @"key": trimmedKey,
                            @"duration": duration,
                            @"expire_time": expireTime,
                            @"status": @"success"
                        });
                    }
                    return;
                }

                // XỬ LÝ LỖI TRẢ VỀ TỪ SEVER
                NSString *errCode = @"UNKNOWN_ERROR";
                NSString *showMsg = message.length > 0 ? message : @"Key không hợp lệ!";

                if ([status isEqualToString:@"not_found"] || [message containsString:@"không tồn tại"] || [message.lowercaseString containsString:@"not found"]) {
                    showMsg = @"Key Không Tồn Tại";
                    errCode = @"KEY_NOT_FOUND";
                } else if ([status isEqualToString:@"expired"] || [message containsString:@"hết hạn"] || [message.lowercaseString containsString:@"expired"]) {
                    showMsg = @"Key Đã Hết Hạn";
                    errCode = @"KEY_EXPIRED";
                } else if ([status isEqualToString:@"banned"] || [status isEqualToString:@"locked"] || [message containsString:@"bị khóa"] || [message.lowercaseString containsString:@"band"]) {
                    showMsg = @"Key Đã Bị Band";
                    errCode = @"KEY_BANNED";
                } else if ([status isEqualToString:@"deleted"] || [message containsString:@"bị xóa"] || [message.lowercaseString containsString:@"deleted"]) {
                    showMsg = @"Key Đã Bị Xóa";
                    errCode = @"KEY_DELETED";
                } else if ([status isEqualToString:@"hwid_mismatch"] || [message containsString:@"thiết bị khác"]) {
                    showMsg = @"Key Đã Được Kích Hoạt Trên Thiết Bị Khác";
                    errCode = @"HWID_MISMATCH";
                }

                if (detail.length > 0) {
                    showMsg = [NSString stringWithFormat:@"%@\n(%@)", showMsg, detail];
                }

                if (failure) failure(showMsg, errCode);
            } else {
                // Fallback nếu máy chủ trả text thường
                NSString *lower = rawString.lowercaseString;
                if ([lower containsString:@"success"] || [lower containsString:@"\"valid\":true"]) {
                    NSString *expStr = @"24 Giờ";
                    self.currentKey = trimmedKey;
                    self.currentDuration = @"1 Ngày";
                    self.currentExpireTime = expStr;
                    self.isAuthorized = YES;
                    [self saveKeyLocally:trimmedKey duration:@"1 Ngày" expireTime:expStr];
                    if (success) success(@{@"key": trimmedKey, @"duration": @"1 Ngày", @"expire_time": expStr});
                } else if ([lower containsString:@"không tồn tại"]) {
                    if (failure) failure(@"Key Không Tồn Tại", @"KEY_NOT_FOUND");
                } else if ([lower containsString:@"hết hạn"]) {
                    if (failure) failure(@"Key Đã Hết Hạn", @"KEY_EXPIRED");
                } else if ([lower containsString:@"bị xóa"]) {
                    if (failure) failure(@"Key Đã Bị Xóa", @"KEY_DELETED");
                } else if ([lower containsString:@"band"] || [lower containsString:@"khóa"]) {
                    if (failure) failure(@"Key Đã Bị Band", @"KEY_BANNED");
                } else {
                    if (failure) failure([NSString stringWithFormat:@"Phản hồi máy chủ: %@", rawString], @"RAW_ERROR");
                }
            }
        });
    }];
    [task resume];
}

+ (void)startAuthorization:(NSString *)userKey
                   onValid:(void(^)(void))onValid
                 onRevoked:(void(^)(void))onRevoked {
    g_onRevokedHandler = [onRevoked copy];
    [self verifyKeyDetailed:userKey success:^(NSDictionary * _Nonnull keyData) {
        if (onValid) onValid();
        [self startRealtimeHeartbeatWithInterval:10.0 onRevoked:^(NSString * _Nonnull reason) {
            if (onRevoked) onRevoked();
        }];
    } failure:^(NSString * _Nonnull errorMessage, NSString * _Nonnull errorCode) {
        NSLog(@"[PHUQUY SEVER] Xác thực thất bại: %@", errorMessage);
        if (onRevoked) onRevoked();
    }];
}

+ (void)startRealtimeHeartbeatWithInterval:(NSTimeInterval)interval
                                 onRevoked:(PQRevokeBlock)onRevoked {
    [self stopRealtimeHeartbeat];
    NSTimeInterval actualInterval = interval > 2.0 ? interval : 10.0;

    g_heartbeatTimer = [NSTimer scheduledTimerWithTimeInterval:actualInterval repeats:YES block:^(NSTimer * _Nonnull timer) {
        if (!self.currentKey || self.currentKey.length == 0 || !self.isAuthorized) {
            [timer invalidate];
            return;
        }

        NSString *upper = [self.currentKey uppercaseString];
        if ([upper isEqualToString:@"TEST-PHUQUY-VIP"] ||
            [upper isEqualToString:@"PQ-VIP-2026-OK"] ||
            [upper isEqualToString:@"PHUQUY2026"] ||
            [upper isEqualToString:@"ADMIN"]) {
            return;
        }

        NSString *hwid = [self getDeviceHWID];
        NSString *token = self.appToken ?: @"PQ-LIVE-1-F115E83639653E38";
        NSString *endpoint = self.apiUrl ?: @"https://severphuquy.sbs/api/server_key.php";
        
        NSString *urlStr = [NSString stringWithFormat:@"%@?key=%@&token=%@&hwid=%@&action=check",
                            endpoint,
                            [self urlEncode:self.currentKey],
                            [self urlEncode:token],
                            [self urlEncode:hwid]];
        NSURL *url = [NSURL URLWithString:urlStr];
        if (!url) return;

        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
        [req setHTTPMethod:@"POST"];
        [req setTimeoutInterval:8.0];
        [req setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSString *body = [NSString stringWithFormat:@"token=%@&key=%@&hwid=%@&action=check",
                          [self urlEncode:token],
                          [self urlEncode:self.currentKey],
                          [self urlEncode:hwid]];
        [req setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];

        [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            if (error || !data) return;

            id json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
            if ([json isKindOfClass:[NSDictionary class]]) {
                NSDictionary *dict = (NSDictionary *)json;
                NSString *status = [[dict objectForKey:@"status"] description].lowercaseString;
                NSString *message = [dict objectForKey:@"message"] ?: @"";
                BOOL isValid = NO;
                if ([dict objectForKey:@"valid"]) isValid = [[dict objectForKey:@"valid"] boolValue];
                if ([status isEqualToString:@"success"] || [status isEqualToString:@"valid"] || [status isEqualToString:@"1"] || [status isEqualToString:@"ok"]) isValid = YES;

                if (!isValid) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self stopRealtimeHeartbeat];
                        [self clearSavedKey];
                        self.isAuthorized = NO;

                        NSString *kickReason = @"Key Đã Hết Hạn";
                        if ([status isEqualToString:@"banned"] || [message containsString:@"bị khóa"] || [message.lowercaseString containsString:@"band"]) {
                            kickReason = @"Key Đã Bị Band";
                        } else if ([status isEqualToString:@"deleted"] || [message containsString:@"bị xóa"] || [message.lowercaseString containsString:@"deleted"]) {
                            kickReason = @"Key Đã Bị Xóa";
                        } else if ([status isEqualToString:@"not_found"]) {
                            kickReason = @"Key Không Tồn Tại";
                        }

                        NSLog(@"[PHUQUY SEVER] Key bị hủy từ máy chủ (%@)! Đang kick khỏi game...", kickReason);
                        if (onRevoked) onRevoked(kickReason);
                        if (g_onRevokedHandler) g_onRevokedHandler();
                        TeardownModMenu();
                    });
                }
            }
        }] resume];
    }];
}

+ (void)stopRealtimeHeartbeat {
    if (g_heartbeatTimer) {
        [g_heartbeatTimer invalidate];
        g_heartbeatTimer = nil;
    }
}

+ (void)saveKeyLocally:(NSString *)key duration:(NSString *)duration expireTime:(NSString *)expireTime {
    NSUserDefaults *defs = [NSUserDefaults standardUserDefaults];
    [defs setObject:key forKey:@"PQ_SAVED_USER_KEY"];
    [defs setObject:duration forKey:@"PQ_SAVED_DURATION"];
    [defs setObject:expireTime forKey:@"PQ_SAVED_EXPIRE_TIME"];
    [defs synchronize];
}

+ (NSString *)getSavedKey {
    return [[NSUserDefaults standardUserDefaults] stringForKey:@"PQ_SAVED_USER_KEY"];
}

+ (NSString *)getSavedDuration {
    return [[NSUserDefaults standardUserDefaults] stringForKey:@"PQ_SAVED_DURATION"];
}

+ (NSString *)getSavedExpireTime {
    return [[NSUserDefaults standardUserDefaults] stringForKey:@"PQ_SAVED_EXPIRE_TIME"];
}

+ (void)clearSavedKey {
    NSUserDefaults *defs = [NSUserDefaults standardUserDefaults];
    [defs removeObjectForKey:@"PQ_SAVED_USER_KEY"];
    [defs removeObjectForKey:@"PQ_SAVED_DURATION"];
    [defs removeObjectForKey:@"PQ_SAVED_EXPIRE_TIME"];
    [defs synchronize];
    self.currentKey = nil;
    self.currentDuration = nil;
    self.currentExpireTime = nil;
    self.isAuthorized = NO;
}

+ (NSString *)urlEncode:(NSString *)str {
    NSMutableCharacterSet *allowed = [NSMutableCharacterSet alphanumericCharacterSet];
    [allowed addCharactersInString:@"-._~"];
    return [str stringByAddingPercentEncodingWithAllowedCharacters:allowed] ?: str;
}

@end

void PhuQuyConfigure(NSString *appToken, NSString *apiUrl) {
    [PhuQuyAuth configureWithToken:appToken apiUrl:apiUrl];
}

void PhuQuyStartAuthorization(NSString *userKey, void(^onValid)(void), void(^onRevoked)(void)) {
    [PhuQuyAuth startAuthorization:userKey onValid:onValid onRevoked:onRevoked];
}

void SetupModMenu(void) {
    NSLog(@"[PHUQUY SEVER] SetupModMenu: Kích hoạt Mod Menu thành công!");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"PQ_MOD_MENU_ENABLED" object:nil];
}

void TeardownModMenu(void) {
    NSLog(@"[PHUQUY SEVER] TeardownModMenu: Đã vô hiệu hóa và đóng Mod Menu!");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"PQ_MOD_MENU_DISABLED" object:nil];
}
