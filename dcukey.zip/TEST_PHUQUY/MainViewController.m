#import "MainViewController.h"
#import "KeyViewController.h"
#import "PhuQuyAuth.h"

@interface MainViewController ()

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIImageView *logoView;
@property (nonatomic, strong) UILabel *appNameLabel;
@property (nonatomic, strong) UIView *badgeStatusView;
@property (nonatomic, strong) UILabel *badgeStatusLabel;

// Info Card
@property (nonatomic, strong) UIVisualEffectView *infoCard;
@property (nonatomic, strong) UILabel *keyLabel;
@property (nonatomic, strong) UILabel *durationLabel;
@property (nonatomic, strong) UILabel *expireLabel;
@property (nonatomic, strong) UILabel *hwidLockLabel;

// Nút Bật kiểu iOS 26
@property (nonatomic, strong) UIVisualEffectView *switchCard;
@property (nonatomic, strong) UILabel *switchTitleLabel;
@property (nonatomic, strong) UILabel *switchSubLabel;
@property (nonatomic, strong) UISwitch *ios26Switch;
@property (nonatomic, strong) UILabel *switchStateLabel;

// Realtime Monitor Card
@property (nonatomic, strong) UIView *heartbeatBar;
@property (nonatomic, strong) UIView *pulseDot;
@property (nonatomic, strong) UILabel *heartbeatLabel;

// Nút Đổi Key / Đăng xuất
@property (nonatomic, strong) UIButton *logoutButton;

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.04 green:0.05 blue:0.08 alpha:1.0];

    [self setupBackground];
    [self setupUI];
    [self startHeartbeatMonitor];
    [self registerNotifications];
}

- (void)setupBackground {
    UIImage *bgImg = [UIImage imageNamed:@"Logo"] ?: [UIImage imageNamed:@"logo.png"] ?: [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]];
    if (bgImg) {
        UIImageView *bgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
        bgView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        bgView.image = bgImg;
        bgView.contentMode = UIViewContentModeScaleAspectFill;
        bgView.alpha = 0.15;
        [self.view addSubview:bgView];
    }

    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
    blurView.frame = self.view.bounds;
    blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:blurView];
}

- (void)setupUI {
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scrollView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:self.scrollView];

    self.contentView = [[UIView alloc] initWithFrame:self.view.bounds];
    self.contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.scrollView addSubview:self.contentView];

    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    CGFloat cardW = MIN(screenW - 36, 390);
    CGFloat cardX = (screenW - cardW) / 2;

    CGFloat topY = 60;

    // Header: Logo + App Name + Status
    UIImage *logoImg = [UIImage imageNamed:@"Logo"] ?: [UIImage imageNamed:@"logo.png"] ?: [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]];
    self.logoView = [[UIImageView alloc] initWithFrame:CGRectMake(cardX, topY, 60, 50)];
    self.logoView.image = logoImg;
    self.logoView.contentMode = UIViewContentModeScaleAspectFit;
    self.logoView.layer.cornerRadius = 12;
    self.logoView.layer.masksToBounds = YES;
    self.logoView.layer.borderWidth = 1.0;
    self.logoView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.3].CGColor;
    [self.contentView addSubview:self.logoView];

    self.appNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(cardX + 70, topY + 2, cardW - 70, 24)];
    self.appNameLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightHeavy];
    self.appNameLabel.textColor = [UIColor whiteColor];
    self.appNameLabel.text = @"TEST PHUQUY";
    [self.contentView addSubview:self.appNameLabel];

    // Badge trạng thái
    self.badgeStatusView = [[UIView alloc] initWithFrame:CGRectMake(cardX + 70, topY + 28, 160, 24)];
    self.badgeStatusView.backgroundColor = [UIColor colorWithRed:0.0 green:0.8 blue:0.4 alpha:0.18];
    self.badgeStatusView.layer.cornerRadius = 12;
    self.badgeStatusView.layer.borderWidth = 1.0;
    self.badgeStatusView.layer.borderColor = [UIColor colorWithRed:0.0 green:0.9 blue:0.5 alpha:0.6].CGColor;
    [self.contentView addSubview:self.badgeStatusView];

    UIView *badgeDot = [[UIView alloc] initWithFrame:CGRectMake(8, 7, 10, 10)];
    badgeDot.backgroundColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.5 alpha:1.0];
    badgeDot.layer.cornerRadius = 5;
    [self.badgeStatusView addSubview:badgeDot];

    self.badgeStatusLabel = [[UILabel alloc] initWithFrame:CGRectMake(24, 2, 130, 20)];
    self.badgeStatusLabel.font = [UIFont boldSystemFontOfSize:11];
    self.badgeStatusLabel.textColor = [UIColor colorWithRed:0.2 green:1.0 blue:0.6 alpha:1.0];
    self.badgeStatusLabel.text = self.isVietnamese ? @"HOẠT ĐỘNG • ĐÃ KHÓA" : @"ACTIVE • LOCKED";
    [self.badgeStatusView addSubview:self.badgeStatusLabel];

    // 1. Thẻ thông tin Key đã xác thực
    CGFloat infoY = topY + 70;
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    self.infoCard = [[UIVisualEffectView alloc] initWithEffect:blur];
    self.infoCard.frame = CGRectMake(cardX, infoY, cardW, 146);
    self.infoCard.layer.cornerRadius = 24;
    self.infoCard.layer.masksToBounds = YES;
    self.infoCard.layer.borderWidth = 1.2;
    self.infoCard.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.2].CGColor;
    self.infoCard.layer.backgroundColor = [UIColor colorWithRed:0.08 green:0.11 blue:0.16 alpha:0.75].CGColor;
    [self.contentView addSubview:self.infoCard];

    UIView *infoInner = self.infoCard.contentView;

    NSString *currentKey = [PhuQuyAuth currentKey] ?: [PhuQuyAuth getSavedKey] ?: @"UNKNOWN";
    NSString *currentDuration = [PhuQuyAuth currentDuration] ?: [PhuQuyAuth getSavedDuration] ?: @"1 Ngày";
    NSString *currentExpire = [PhuQuyAuth currentExpireTime] ?: [PhuQuyAuth getSavedExpireTime] ?: @"24 Giờ";
    NSString *hwid = [PhuQuyAuth getDeviceHWID];
    NSString *shortHwid = hwid.length > 16 ? [NSString stringWithFormat:@"%@...%@", [hwid substringToIndex:8], [hwid substringFromIndex:hwid.length-6]] : hwid;

    self.keyLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 12, cardW - 32, 24)];
    self.keyLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    self.keyLabel.textColor = [UIColor whiteColor];
    self.keyLabel.text = [NSString stringWithFormat:@"🔑 KEY: %@", currentKey];
    [infoInner addSubview:self.keyLabel];

    self.durationLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 38, cardW - 32, 24)];
    self.durationLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    self.durationLabel.textColor = [UIColor colorWithRed:0.3 green:0.85 blue:1.0 alpha:1.0];
    self.durationLabel.text = [NSString stringWithFormat:self.isVietnamese ? @"⏳ THỜI HẠN: %@" : @"⏳ DURATION: %@", currentDuration];
    [infoInner addSubview:self.durationLabel];

    self.expireLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 64, cardW - 32, 24)];
    self.expireLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    self.expireLabel.textColor = [UIColor colorWithRed:1.0 green:0.85 blue:0.4 alpha:1.0];
    self.expireLabel.text = [NSString stringWithFormat:self.isVietnamese ? @"📅 HẾT HẠN: %@" : @"📅 EXPIRES AT: %@", currentExpire];
    [infoInner addSubview:self.expireLabel];

    self.hwidLockLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 92, cardW - 32, 42)];
    self.hwidLockLabel.font = [UIFont fontWithName:@"Menlo" size:11] ?: [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    self.hwidLockLabel.textColor = [UIColor colorWithWhite:0.75 alpha:1.0];
    self.hwidLockLabel.numberOfLines = 2;
    self.hwidLockLabel.text = [NSString stringWithFormat:self.isVietnamese ? @"🔒 Khóa cứng thiết bị HWID:\n%@" : @"🔒 Locked to Device HWID:\n%@", shortHwid];
    [infoInner addSubview:self.hwidLockLabel];

    // 2. NÚT BẬT KIỂU IOS 26 (FUTURISTIC NEON TOGGLE)
    CGFloat switchY = infoY + 162;
    self.switchCard = [[UIVisualEffectView alloc] initWithEffect:blur];
    self.switchCard.frame = CGRectMake(cardX, switchY, cardW, 136);
    self.switchCard.layer.cornerRadius = 24;
    self.switchCard.layer.masksToBounds = YES;
    self.switchCard.layer.borderWidth = 1.5;
    self.switchCard.layer.borderColor = [UIColor colorWithRed:0.0 green:0.8 blue:0.6 alpha:0.4].CGColor;
    self.switchCard.layer.backgroundColor = [UIColor colorWithRed:0.06 green:0.12 blue:0.16 alpha:0.85].CGColor;
    [self.contentView addSubview:self.switchCard];

    UIView *switchInner = self.switchCard.contentView;

    self.switchTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, 16, cardW - 100, 26)];
    self.switchTitleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightHeavy];
    self.switchTitleLabel.textColor = [UIColor whiteColor];
    self.switchTitleLabel.text = self.isVietnamese ? @"NÚT BẬT KIỂU IOS 26" : @"IOS 26 TOGGLE SWITCH";
    [switchInner addSubview:self.switchTitleLabel];

    self.switchSubLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, 44, cardW - 100, 20)];
    self.switchSubLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
    self.switchSubLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    self.switchSubLabel.text = self.isVietnamese ? @"Chạm để bật/tắt Mod Menu" : @"Tap to toggle Mod Menu";
    [switchInner addSubview:self.switchSubLabel];

    // Nút Bật UISwitch phong cách iOS 26
    self.ios26Switch = [[UISwitch alloc] initWithFrame:CGRectMake(cardW - 74, 28, 56, 34)];
    self.ios26Switch.onTintColor = [UIColor colorWithRed:0.0 green:0.9 blue:0.6 alpha:1.0];
    self.ios26Switch.thumbTintColor = [UIColor whiteColor];
    self.ios26Switch.on = YES;
    [self.ios26Switch addTarget:self action:@selector(switchToggled:) forControlEvents:UIControlEventValueChanged];
    [switchInner addSubview:self.ios26Switch];

    self.switchStateLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, 86, cardW - 36, 32)];
    self.switchStateLabel.backgroundColor = [UIColor colorWithRed:0.0 green:0.8 blue:0.5 alpha:0.15];
    self.switchStateLabel.layer.cornerRadius = 10;
    self.switchStateLabel.layer.masksToBounds = YES;
    self.switchStateLabel.font = [UIFont boldSystemFontOfSize:13];
    self.switchStateLabel.textAlignment = NSTextAlignmentCenter;
    self.switchStateLabel.textColor = [UIColor colorWithRed:0.1 green:1.0 blue:0.6 alpha:1.0];
    self.switchStateLabel.text = self.isVietnamese ? @"● TRẠNG THÁI: ĐANG BẬT" : @"● STATUS: ENABLED";
    [switchInner addSubview:self.switchStateLabel];

    // Kích hoạt ban đầu
    SetupModMenu();

    // 3. Thanh giám sát Realtime Heartbeat với Máy Chủ
    CGFloat heartY = switchY + 152;
    self.heartbeatBar = [[UIView alloc] initWithFrame:CGRectMake(cardX, heartY, cardW, 44)];
    self.heartbeatBar.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.8];
    self.heartbeatBar.layer.cornerRadius = 14;
    self.heartbeatBar.layer.borderWidth = 1.0;
    self.heartbeatBar.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.15].CGColor;
    [self.contentView addSubview:self.heartbeatBar];

    self.pulseDot = [[UIView alloc] initWithFrame:CGRectMake(14, 17, 10, 10)];
    self.pulseDot.backgroundColor = [UIColor colorWithRed:0.2 green:0.85 blue:1.0 alpha:1.0];
    self.pulseDot.layer.cornerRadius = 5;
    [self.heartbeatBar addSubview:self.pulseDot];

    [self startPulseAnimation:self.pulseDot];

    self.heartbeatLabel = [[UILabel alloc] initWithFrame:CGRectMake(32, 10, cardW - 44, 24)];
    self.heartbeatLabel.font = [UIFont systemFontOfSize:11.5 weight:UIFontWeightBold];
    self.heartbeatLabel.textColor = [UIColor colorWithRed:0.4 green:0.85 blue:1.0 alpha:1.0];
    self.heartbeatLabel.text = self.isVietnamese ? @"Đồng bộ Realtime: Kết nối Máy Chủ PHUQUY" : @"Realtime Sync: Connected to PHUQUY Server";
    [self.heartbeatBar addSubview:self.heartbeatLabel];

    // 4. Nút Đổi Key / Đăng Xuất
    CGFloat logoutY = heartY + 58;
    self.logoutButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.logoutButton.frame = CGRectMake(cardX, logoutY, cardW, 48);
    self.logoutButton.backgroundColor = [UIColor colorWithRed:0.35 green:0.1 blue:0.15 alpha:0.7];
    self.logoutButton.layer.cornerRadius = 14;
    self.logoutButton.layer.borderWidth = 1.0;
    self.logoutButton.layer.borderColor = [UIColor colorWithRed:0.8 green:0.2 blue:0.25 alpha:0.5].CGColor;
    self.logoutButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    [self.logoutButton setTitleColor:[UIColor colorWithRed:1.0 green:0.6 blue:0.6 alpha:1.0] forState:UIControlStateNormal];
    [self.logoutButton setTitle:self.isVietnamese ? @"🚪 Đổi Key / Đăng Xuất" : @"🚪 Change Key / Logout" forState:UIControlStateNormal];
    [self.logoutButton addTarget:self action:@selector(logoutAction) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.logoutButton];
}

- (void)startPulseAnimation:(UIView *)view {
    [UIView animateWithDuration:0.9 delay:0.0 options:UIViewAnimationOptionAutoreverse | UIViewAnimationOptionRepeat animations:^{
        view.alpha = 0.2;
        view.transform = CGAffineTransformMakeScale(1.3, 1.3);
    } completion:nil];
}

- (void)switchToggled:(UISwitch *)sender {
    if (sender.isOn) {
        SetupModMenu();
        self.switchStateLabel.backgroundColor = [UIColor colorWithRed:0.0 green:0.8 blue:0.5 alpha:0.15];
        self.switchStateLabel.textColor = [UIColor colorWithRed:0.1 green:1.0 blue:0.6 alpha:1.0];
        self.switchStateLabel.text = self.isVietnamese ? @"● TRẠNG THÁI: ĐANG BẬT" : @"● STATUS: ENABLED";
    } else {
        TeardownModMenu();
        self.switchStateLabel.backgroundColor = [UIColor colorWithWhite:0.15 alpha:0.5];
        self.switchStateLabel.textColor = [UIColor colorWithWhite:0.6 alpha:1.0];
        self.switchStateLabel.text = self.isVietnamese ? @"○ TRẠNG THÁI: ĐÃ TẮT" : @"○ STATUS: DISABLED";
    }

    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *impact = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
        [impact impactOccurred];
    }
}

#pragma mark - Realtime Kick Mechanism

- (void)startHeartbeatMonitor {
    // Khởi chạy Heartbeat 10s một lần gọi tới máy chủ severphuquy.sbs
    [PhuQuyAuth startRealtimeHeartbeatWithInterval:10.0 onRevoked:^(NSString * _Nonnull reason) {
        [self handleServerKickWithReason:reason];
    }];
}

- (void)handleServerKickWithReason:(NSString *)kickReason {
    NSLog(@"[PHUQUY SEVER] BỊ KICK KHỎI MENU: %@", kickReason);

    // Dừng Mod Menu lập tức
    TeardownModMenu();

    // Hiển thị thông báo kick và đẩy về màn hình nhập Key
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:self.isVietnamese ? @"THÔNG BÁO BẢN QUYỀN" : @"LICENSE NOTICE"
                                                                   message:kickReason
                                                            preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *okAction = [UIAlertAction actionWithTitle:self.isVietnamese ? @"Nhập Key Mới" : @"Enter New Key"
                                                       style:UIAlertActionStyleDestructive
                                                     handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:^{
            KeyViewController *keyVC = (KeyViewController *)self.presentingViewController;
            if ([keyVC isKindOfClass:[KeyViewController class]]) {
                [keyVC showKickReason:kickReason];
            }
        }];
    }];
    [alert addAction:okAction];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)logoutAction {
    [PhuQuyAuth stopRealtimeHeartbeat];
    [PhuQuyAuth clearSavedKey];
    TeardownModMenu();

    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)registerNotifications {
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onMenuDisabled)
                                                 name:@"PQ_MOD_MENU_DISABLED"
                                               object:nil];
}

- (void)onMenuDisabled {
    if (self.ios26Switch.isOn) {
        [self.ios26Switch setOn:NO animated:YES];
        self.switchStateLabel.backgroundColor = [UIColor colorWithWhite:0.15 alpha:0.5];
        self.switchStateLabel.textColor = [UIColor colorWithWhite:0.6 alpha:1.0];
        self.switchStateLabel.text = self.isVietnamese ? @"○ TRẠNG THÁI: ĐÃ TẮT" : @"○ STATUS: DISABLED";
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

@end
