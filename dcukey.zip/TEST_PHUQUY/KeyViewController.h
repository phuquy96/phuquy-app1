#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KeyViewController : UIViewController

/// Hiển thị thông báo kick hoặc lỗi từ ngoài (khi bị kick từ Main)
- (void)showKickReason:(NSString *)reason;

@end

NS_ASSUME_NONNULL_END
