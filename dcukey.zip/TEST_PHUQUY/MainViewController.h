#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MainViewController : UIViewController

@property (nonatomic, assign) BOOL isVietnamese;

@end

NS_ASSUME_NONNULL_END
