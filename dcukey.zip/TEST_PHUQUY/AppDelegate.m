#import "AppDelegate.h"
#import "KeyViewController.h"
#import "PhuQuyAuth.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // 1. Cấu hình Máy Chủ PHUQUY
    PhuQuyConfigure(@"PQ-LIVE-1-F115E83639653E38", @"https://severphuquy.sbs/api/server_key.php");

    // 2. Khởi tạo giao diện chính cho iOS < 13
    if (@available(iOS 13.0, *)) {
        // Handled by SceneDelegate
    } else {
        self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        KeyViewController *keyVC = [[KeyViewController alloc] init];
        self.window.rootViewController = keyVC;
        [self.window makeKeyAndVisible];
    }

    return YES;
}

#pragma mark - UISceneSession lifecycle

- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options API_AVAILABLE(ios(13.0)) {
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}

- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions API_AVAILABLE(ios(13.0)) {
}

@end
